# coniox
coniox is a conio library replacement that implementents conio.h functions in Borland/Turbo C compatible with DOS16/DOS32 and Windows suitable for Borland, Zortech/Symantec/DigitalMars and Watcom/Openwatcom compilers among others.

If you are already using Turbo/Borland conio.h in you DOS development, coniox will have same functionality, but with a performance being 1.5x to 3x faster.


DOS
CONIO		4.3s	2.7s	2.7s
DIRIO 2.4	1.0s	0.6s	0.83s
CONIOX 5	2.5s	0.9s	1.4s

Windows
CONIOX	5	2.4s	1.4s	1.9s

